@extends('layouts.html')


@section('header')
@include('layouts.header')

@endsection

@section('headnav')
@include('layouts.headnav')
@include('layouts.faq')
@endsection

@section('about')
@include('layouts.about')
@endsection

@section('service')
@include('layouts.service')
@endsection

@section('appstore')
@include('layouts.appstore')
@endsection

@section('team')
@include('layouts.team')
@endsection

@section('footer')
@include('layouts.footer')
@endsection