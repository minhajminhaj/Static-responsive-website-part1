<!doctype html>
<html class="no-js" lang="zxx">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>CreativePhoto HTML Template</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Place favicon.ico in the root directory -->
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">
    <link rel="shortcut icon" type="image/ico" href="images/favicon.ico" />
    <!-- Plugin-CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/animate.css">
    <!-- Main-Stylesheets -->
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/space.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body data-spy="scroll" data-target="#mainmenu">
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        
    <!--Preloader-->
    <div class="preloader">
        <div class="vcenter">
            <div class="sk-double-bounce">
                <div class="sk-child sk-double-bounce1"></div>
                <div class="sk-child sk-double-bounce2"></div>
            </div>
        </div>
    </div>
    <!--Preloade/r-->
    <header class="relative" id="home">
        <div class="absolute section-overlay home-slide fix">
            <img src="images/bg/bg3.jpg" alt="">
            <img src="images/bg/bg2.jpg" alt="">
            <img src="images/bg/bg1.jpeg" alt="">
            <img src="images/bg/bg4.jpg" alt="">
        </div>
        <!--Mainmenu-area-->
        <nav class="navbar navbar-inverse mainmenu-area navbar-fixed-top smoth" data-spy="affix" data-offset-top="3">
            <div class="container relative">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainmenu">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a href="#home" class="navbar-brand logo"><img src="images/logo.png" alt=""></a>
                </div>
                <div id="mainmenu" class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li><a href="#home">Home</a></li>
                        <li><a href="#about">About</a></li>
                        <li><a href="#service">Service</a></li>
                        <li><a href="#work">Work</a></li>
                        <li><a href="#team">Team</a></li>
                        <li><a href="#client">Client</a></li>
                        <li><a href="#blog">Blog</a></li>
                        <li><a href="#contact">Contact</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <!--Mainmenu-area/-->
        <!--Header-text-->
        <div class="container">
            <div class="row text-white">
                <div class="space-100"></div>
                <div class="space-100"></div>
                <div class="space-100 hidden-xs"></div>
                <div class="col-xs-12 text-center wow fadeIn" data-wow-delay="0.6s">
                    <h2 class="head-title">We Have Amazing <span class="type">photographer</span></h2>
                    <div class="space-10"></div>
                    <p>Pellentesque sodales sem at sagittis laoreet. Nulla nec ornare nibh. Lorem ipsum dolor
                        <br> sitamet,onsectetur adipiscing elit. Ut sed sapie</p>
                    <div class="space-30"></div>
                    <a href="#" class="btn btn-warning round">View more</a>
                </div>
                <div class="space-100"></div>
                <div class="space-100"></div>
            </div>
        </div>
        <!--Header-text/-->
    </header>
    <!--About-area-->
    <section id="about">
        <div class="space-100"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-md-8 col-md-offset-2 text-center wow fadeInUp">
                    <h2 class="page-title text-capitalize">About Our <span>Store</span></h2>
                    <div class="space-20"></div>
                    <p>loremloreInterdum et malesuada fames ac ante ipsum primis in faucibus. Maecenas eget maximus purus. MaVestibulum ante ipsum primis in fauci tristique vestibulum ultricies. Donec vehicula elementum lectus, id accumsan ligula lacini Duis non velit non mi viverra rutrum. Maur Aenean efficitur ullamcorper orci ut rhoncus. Vivamus mattis nisl lacus, loeim isam dollae jarDuis non velit non mi viverra rutrum. Mauris enenatis porttitor arcu aliquet at. Donec molestie mollis ex vitae dignissim. Curabitur ante sem, tempor at nisi ac, blandit condimentum elit.</p>
                    <div id="more_about" class="collapse">
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquam esse dolore ipsam quia suscipit explicabo cumque voluptas molestiae, eveniet, reiciendis doloribus dicta neque laudantium officia non animi. Explicabo similique, quibusdam consectetur laudantium. In alias quisquam mollitia impedit nihil, eligendi dolore blanditiis, rem laudantium, quae doloribus amet dolor architecto. Repudiandae, nihil.</p>
                    </div>
                    <div class="space-15"></div>
                    <a href="#more_about" class="btn btn-warning" data-toggle="collapse">Read more</a>
                </div>
            </div>
        </div>
        <div class="space-100"></div>
    </section>
    <!--About-area/-->
    <!--Service-area-->
    <section class="dark-bg" id="service">
        <div class="space-100"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-sm-offset-3 text-center">
                    <h2 class="page-title text-capitalize">our <span>Service</span></h2>
                    <p>Morbi consectetur felis nibh, vel condimentum
                        <br> velit vulputate vitae</p>
                </div>
            </div>
            <div class="space-60"></div>
            <div class="row wow fadeInUp">
                <div class="col-xs-12 col-sm-5 col-md-3">
                    <div class="space-20"></div>
                    <ul class="list-unstyled service-menu">
                        <li class="active"><a data-toggle="tab" href="#service_1">01. Branding Design</a></li>
                        <li><a data-toggle="tab" href="#service_2">02. Marketing Solutions</a></li>
                        <li><a data-toggle="tab" href="#service_3">0.3 Photography</a></li>
                        <li><a data-toggle="tab" href="#service_4">0.4 Digital Illustration</a></li>
                        <li><a data-toggle="tab" href="#service_5">0.5 UI Design</a></li>
                    </ul>
                </div>
                <div class="col-xs-12 col-sm-7 col-md-9">
                    <div class="tab-content">
                        <div class="tab-pane fade in active" id="service_1">
                            <div class="row">
                                <div class="col-xs-12 col-md-5">
                                    <div class="service-photo">
                                        <img src="images/service/service-1.jpg" alt="" class="img-thumbnail">
                                    </div>
                                </div>
                                <div class="col-xs-12 col-md-7">
                                    <div class="space-20"></div>
                                    <h2>Branding Design</h2>
                                    <div class="space-10"></div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. o eiusmod tempor incididunt ut labore et dolore magna aliqua. dolore magna aliqua. Ut enim ad minim veniam, Qfis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="service_2">
                            <div class="row">
                                <div class="col-xs-12 col-md-5">
                                    <div class="service-photo">
                                        <img src="images/service/service-2.jpg" alt="" class="img-thumbnail">
                                    </div>
                                </div>
                                <div class="col-xs-12 col-md-7">
                                    <div class="space-20"></div>
                                    <h2>Marketing Solutions</h2>
                                    <div class="space-10"></div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. o eiusmod tempor incididunt ut labore et dolore magna aliqua. dolore magna aliqua. Ut enim ad minim veniam, Qfis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="service_3">
                            <div class="row">
                                <div class="col-xs-12 col-md-5">
                                    <div class="service-photo">
                                        <img src="images/service/service--3.jpg" alt="" class="img-thumbnail">
                                    </div>
                                </div>
                                <div class="col-xs-12 col-md-7">
                                    <div class="space-20"></div>
                                    <h2>Photography</h2>
                                    <div class="space-10"></div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. o eiusmod tempor incididunt ut labore et dolore magna aliqua. dolore magna aliqua. Ut enim ad minim veniam, Qfis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="service_4">
                            <div class="row">
                                <div class="col-xs-12 col-md-5">
                                    <div class="service-photo">
                                        <img src="images/service/service-4.jpg" alt="" class="img-thumbnail">
                                    </div>
                                </div>
                                <div class="col-xs-12 col-md-7">
                                    <div class="space-20"></div>
                                    <h2>Digital Illustration</h2>
                                    <div class="space-10"></div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. o eiusmod tempor incididunt ut labore et dolore magna aliqua. dolore magna aliqua. Ut enim ad minim veniam, Qfis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="service_5">
                            <div class="row">
                                <div class="col-xs-12 col-md-5">
                                    <div class="service-photo">
                                        <img src="images/service/service-5.jpg" alt="" class="img-thumbnail">
                                    </div>
                                </div>
                                <div class="col-xs-12 col-md-7">
                                    <div class="space-20"></div>
                                    <h2>Digital Illustration</h2>
                                    <div class="space-10"></div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. o eiusmod tempor incididunt ut labore et dolore magna aliqua. dolore magna aliqua. Ut enim ad minim veniam, Qfis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="space-100"></div>
    </section>
    <!--Service-area/-->
    <!--Work-area-->
    <section id="work">
        <div class="space-100"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-sm-offset-3 text-center">
                    <h2 class="page-title text-capitalize">See Our <span>Photoshot</span></h2>
                    <p>Morbi consectetur felis nibh, vel condimentum
                        <br> velit vulputate vitae</p>
                </div>
            </div>
            <div class="space-60"></div>
            <div class="row" id="grid">
                <div class="col-xs-12 col-sm-4 grid-item wow fadeInUp">
                    <div class="single-photo efbarm">
                        <div class="efbar">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <img src="images/work/b1.jpg" alt="">
                        <div class="vcenter">
                            <div class="photo-details text-center">
                                <h3>photography</h3>
                                <div class="space-10"></div>
                                <ul class="list-inline list-unstyled photo-icon">
                                    <li><a href="#"><i class="fa fa-tag"></i></a></li>
                                    <li><a href="images/work/b1.jpg" class="photo-popup"><i class="fa fa-photo"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="space-30"></div>
                </div>
                <div class="col-xs-12 col-sm-4 grid-item wow fadeInUp">
                    <div class="single-photo efbarm">
                        <div class="efbar">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <img src="images/work/m1.jpg" alt="">
                        <div class="vcenter">
                            <div class="photo-details text-center">
                                <h3>photography</h3>
                                <div class="space-10"></div>
                                <ul class="list-inline list-unstyled photo-icon">
                                    <li><a href="#"><i class="fa fa-tag"></i></a></li>
                                    <li><a href="images/work/m1.jpg" class="photo-popup"><i class="fa fa-photo"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="space-30"></div>
                </div>
                <div class="col-xs-12 col-sm-4 grid-item wow fadeInUp">
                    <div class="single-photo efbarm">
                        <div class="efbar">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <img src="images/work/b2.jpg" alt="">
                        <div class="vcenter">
                            <div class="photo-details text-center">
                                <h3>photography</h3>
                                <div class="space-10"></div>
                                <ul class="list-inline list-unstyled photo-icon">
                                    <li><a href="#"><i class="fa fa-tag"></i></a></li>
                                    <li><a href="images/work/b2.jpg" class="photo-popup"><i class="fa fa-photo"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="space-30"></div>
                </div>
                <div class="col-xs-12 col-sm-4 grid-item wow fadeInUp">
                    <div class="single-photo efbarm">
                        <div class="efbar">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <img src="images/work/m2.jpg" alt="">
                        <div class="vcenter">
                            <div class="photo-details text-center">
                                <h3>photography</h3>
                                <div class="space-10"></div>
                                <ul class="list-inline list-unstyled photo-icon">
                                    <li><a href="#"><i class="fa fa-tag"></i></a></li>
                                    <li><a href="images/work/m2.jpg" class="photo-popup"><i class="fa fa-photo"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="space-30"></div>
                </div>
                <div class="col-xs-12 col-sm-4 grid-item wow fadeInUp">
                    <div class="single-photo efbarm">
                        <div class="efbar">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <img src="images/work/b3.jpg" alt="">
                        <div class="vcenter">
                            <div class="photo-details text-center">
                                <h3>photography</h3>
                                <div class="space-10"></div>
                                <ul class="list-inline list-unstyled photo-icon">
                                    <li><a href="#"><i class="fa fa-tag"></i></a></li>
                                    <li><a href="images/work/b3.jpg" class="photo-popup"><i class="fa fa-photo"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="space-30"></div>
                </div>
                <div class="col-xs-12 col-sm-4 grid-item wow fadeInUp">
                    <div class="single-photo efbarm">
                        <div class="efbar">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <img src="images/work/m3.jpg" alt="">
                        <div class="vcenter">
                            <div class="photo-details text-center">
                                <h3>photography</h3>
                                <div class="space-10"></div>
                                <ul class="list-inline list-unstyled photo-icon">
                                    <li><a href="#"><i class="fa fa-tag"></i></a></li>
                                    <li><a href="images/work/m3.jpg" class="photo-popup"><i class="fa fa-photo"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="space-30"></div>
                </div>
                <div class="col-xs-12 col-sm-4 grid-item wow fadeInUp">
                    <div class="single-photo efbarm">
                        <div class="efbar">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <img src="images/work/b4.jpg" alt="">
                        <div class="vcenter">
                            <div class="photo-details text-center">
                                <h3>photography</h3>
                                <div class="space-10"></div>
                                <ul class="list-inline list-unstyled photo-icon">
                                    <li><a href="#"><i class="fa fa-tag"></i></a></li>
                                    <li><a href="images/work/b4.jpg" class="photo-popup"><i class="fa fa-photo"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="space-30"></div>
                </div>
                <div class="col-xs-12 col-sm-4 grid-item wow fadeInUp">
                    <div class="single-photo efbarm">
                        <div class="efbar">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <img src="images/work/m4.jpg" alt="">
                        <div class="vcenter">
                            <div class="photo-details text-center">
                                <h3>photography</h3>
                                <div class="space-10"></div>
                                <ul class="list-inline list-unstyled photo-icon">
                                    <li><a href="#"><i class="fa fa-tag"></i></a></li>
                                    <li><a href="images/work/m4.jpg" class="photo-popup"><i class="fa fa-photo"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="space-30"></div>
                </div>
                <div class="col-xs-12 col-sm-4 grid-item wow fadeInUp">
                    <div class="single-photo efbarm">
                        <div class="efbar">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <img src="images/work/m5.jpg" alt="">
                        <div class="vcenter">
                            <div class="photo-details text-center">
                                <h3>photography</h3>
                                <div class="space-10"></div>
                                <ul class="list-inline list-unstyled photo-icon">
                                    <li><a href="#"><i class="fa fa-tag"></i></a></li>
                                    <li><a href="images/work/m5.jpg" class="photo-popup"><i class="fa fa-photo"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="space-30"></div>
                </div>
            </div>
            <div class="space-50"></div>
            <div class="row">
                <div class="col-xs-12 text-center">
                    <a href="#" class="btn btn-warning">See more</a>
                </div>
            </div>
        </div>
        <div class="space-100"></div>
    </section>
    <!--Work-area/-->
    <!--Team-area-->
    <section class="dark-bg" id="team">
        <div class="space-100"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-sm-offset-3 text-center">
                    <h2 class="page-title text-capitalize">Meet Our <span>Team</span></h2>
                    <p>Morbi consectetur felis nibh, vel condimentum
                        <br> velit vulputate vitae</p>
                </div>
                <div class="space-60"></div>
            </div>
            <div class="row text-center">
                <div class="col-xs-12 col-sm-4 wow fadeInUp" data-wow-delay="0.2s">
                    <div class="single-team relative efbarm">
                        <div class="efbar">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div class="team-photo">
                            <img src="images/team/team1.jpg" alt="">
                        </div>
                        <div class="vcenter">
                            <div class="team-details">
                                <h3 class="team-title">Jhon doe</h3>
                                <p>Head Of Creative Ideas</p>
                                <ul class="list-unstyled list-inline team-soical">
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="single-team relative efbarm">
                        <div class="efbar">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div class="team-photo">
                            <img src="images/team/team2.jpg" alt="">
                        </div>
                        <div class="vcenter">
                            <div class="team-details">
                                <h3 class="team-title">Zakulin Fernandez</h3>
                                <p>Head Of Creative Ideas</p>
                                <ul class="list-unstyled list-inline team-soical">
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4 wow fadeInUp" data-wow-delay="0.4s">
                    <div class="single-team relative efbarm">
                        <div class="efbar">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div class="team-photo">
                            <img src="images/team/team3.jpg" alt="">
                        </div>
                        <div class="vcenter">
                            <div class="team-details">
                                <h3 class="team-title">Thomas Martin</h3>
                                <p>Head Of Creative Ideas</p>
                                <ul class="list-unstyled list-inline team-soical">
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="space-100"></div>
    </section>
    <!--Team-area/-->
    <!--Testimonial-area-->
    <section id="client">
        <div class="space-100"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-sm-offset-3 text-uppercase text-center">
                    <h2 class="page-title text-capitalize">our client <span>love</span></h2>
                    <p>Lorem ipsum dolor sit amet, consectetur.</p>
                </div>
            </div>
            <div class="space-60"></div>
            <div class="row">
                <div class="col-xs-12">
                    <div class="testimonials">
                        <div class="single-testi">
                            <div class="testi-dt relative">
                                <h4>Andrew Rasel</h4>
                                <h6>CEO of Quomodotheme</h6>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis natus, laudantium esse labore perferendis, expedita deserunt et quas repudiandae laborum.</p>
                            </div>
                            <div class="space-30"></div>
                            <div class="testi-photo">
                                <img src="images/testimonial/client1.png" class="img-thumbnail img-circle" alt="">
                            </div>
                        </div>
                        <div class="single-testi">
                            <div class="testi-dt relative">
                                <h4>Andrew Rasel</h4>
                                <h6>CEO of Quomodotheme</h6>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis natus, laudantium esse labore perferendis, expedita deserunt et quas repudiandae laborum.</p>
                            </div>
                            <div class="space-30"></div>
                            <div class="testi-photo">
                                <img src="images/testimonial/client2.png" class="img-thumbnail img-circle" alt="">
                            </div>
                        </div>
                        <div class="single-testi">
                            <div class="testi-dt relative">
                                <h4>Andrew Rasel</h4>
                                <h6>CEO of Quomodotheme</h6>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis natus, laudantium esse labore perferendis, expedita deserunt et quas repudiandae laborum.</p>
                            </div>
                            <div class="space-30"></div>
                            <div class="testi-photo">
                                <img src="images/testimonial/client3.png" class="img-thumbnail img-circle" alt="">
                            </div>
                        </div>
                        <div class="single-testi">
                            <div class="testi-dt relative">
                                <h4>Andrew Rasel</h4>
                                <h6>CEO of Quomodotheme</h6>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis natus, laudantium esse labore perferendis, expedita deserunt et quas repudiandae laborum.</p>
                            </div>
                            <div class="space-30"></div>
                            <div class="testi-photo">
                                <img src="images/testimonial/client4.png" class="img-thumbnail img-circle" alt="">
                            </div>
                        </div>
                        <div class="single-testi">
                            <div class="testi-dt relative">
                                <h4>Andrew Rasel</h4>
                                <h6>CEO of Quomodotheme</h6>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis natus, laudantium esse labore perferendis, expedita deserunt et quas repudiandae laborum.</p>
                            </div>
                            <div class="space-30"></div>
                            <div class="testi-photo">
                                <img src="images/testimonial/client2.png" class="img-thumbnail img-circle" alt="">
                            </div>
                        </div>
                        <div class="single-testi">
                            <div class="testi-dt relative">
                                <h4>Andrew Rasel</h4>
                                <h6>CEO of Quomodotheme</h6>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis natus, laudantium esse labore perferendis, expedita deserunt et quas repudiandae laborum.</p>
                            </div>
                            <div class="space-30"></div>
                            <div class="testi-photo">
                                <img src="images/testimonial/client3.png" class="img-thumbnail img-circle" alt="">
                            </div>
                        </div>
                        <div class="single-testi">
                            <div class="testi-dt relative">
                                <h4>Andrew Rasel</h4>
                                <h6>CEO of Quomodotheme</h6>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis natus, laudantium esse labore perferendis, expedita deserunt et quas repudiandae laborum.</p>
                            </div>
                            <div class="space-30"></div>
                            <div class="testi-photo">
                                <img src="images/testimonial/client4.png" class="img-thumbnail img-circle" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="space-100"></div>
    </section>
    <!--Testimonial-area/-->
    <!--CounterUp-->
    <section class="relative">
        <div class="absolute section-bg bg1"></div>
        <div class="space-100"></div>
        <div class="container">
            <div class="row text-center">
                <div class="col-xs-12 col-sm-3 wow fadeInUp" data-wow-delay="0.2s">
                    <div class="single-counter">
                        <div class="counter-icon">
                            <i class="fa fa-coffee"></i>
                        </div>
                        <div class="space-10"></div>
                        <h4>Copy of Tea</h4>
                        <div class="space-10"></div>
                        <h4><span class="count">1200</span>+</h4>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-3 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="single-counter">
                        <div class="counter-icon">
                            <i class="fa fa-heart-o"></i>
                        </div>
                        <div class="space-10"></div>
                        <h4>Happy Client</h4>
                        <div class="space-10"></div>
                        <h4><span class="count">800</span>+</h4>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-3 wow fadeInUp" data-wow-delay="0.4s">
                    <div class="single-counter">
                        <div class="counter-icon">
                            <i class="fa fa-briefcase"></i>
                        </div>
                        <div class="space-10"></div>
                        <h4>Project Complete</h4>
                        <div class="space-10"></div>
                        <h4><span class="count">985</span>+</h4>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-3 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="single-counter">
                        <div class="counter-icon">
                            <i class="fa fa-trophy"></i>
                        </div>
                        <div class="space-10"></div>
                        <h4>Awards Win</h4>
                        <div class="space-10"></div>
                        <h4><span class="count">650</span>+</h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="space-100"></div>
    </section>
    <!--CounterUp/-->
    <!--Blog-area-->
    <section class="dark-bg" id="blog">
        <div class="space-100"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-sm-offset-3 text-center">
                    <h2 class="page-title text-capitalize">Our <span>Story</span></h2>
                    <p>Morbi consectetur felis nibh, vel condimentum
                        <br> velit vulputate vitae</p>
                </div>
                <div class="space-60"></div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-6 wow fadeInUp">
                    <div class="single-blog">
                        <div class="blog-photo">
                            <img src="images/blog/image-1.jpg" alt="">
                        </div>
                        <div class="blog-details">
                            <h3 class="basic-title"><a href="#">Beautiful Place for your Great Journey</a></h3>
                            <ul class="list-inline list-unstyled">
                                <li><a href="#"><i class="fa fa-user-o"></i> By Admin</a></li>
                                <li><a href="#"><i class="fa fa-eue"></i> 22 Views</a></li>
                                <li><a href="#"><i class="fa fa-share"></i> Share</a></li>
                            </ul>
                            <div class="space-20"></div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae, fuga iure voluptas quod quis blanditiis! Vel odit omnis, itaque, ipsa animi qui excepturi quasi, sed sint mollitia autem tempora iure!</p>
                            <div class="space-15"></div>
                            <a href="#" class="read-more">Read more</a>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 wow fadeInUp">
                    <div class="single-blog">
                        <div class="blog-photo">
                            <img src="images/blog/image-2.jpg" alt="">
                        </div>
                        <div class="blog-details">
                            <h3 class="basic-title"><a href="#">Beautiful Place for your Great Journey</a></h3>
                            <ul class="list-inline list-unstyled">
                                <li><a href="#"><i class="fa fa-user-o"></i> By Admin</a></li>
                                <li><a href="#"><i class="fa fa-eue"></i> 22 Views</a></li>
                                <li><a href="#"><i class="fa fa-share"></i> Share</a></li>
                            </ul>
                            <div class="space-20"></div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae, fuga iure voluptas quod quis blanditiis! Vel odit omnis, itaque, ipsa animi qui excepturi quasi, sed sint mollitia autem tempora iure!</p>
                            <div class="space-15"></div>
                            <a href="#" class="read-more">Read more</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="space-100"></div>
    </section>
    <!--Blog-area/-->
    <!--Footer-area-->
    <footer id="contact">
        <div class="space-100"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-sm-offset-3 text-center">
                    <h2 class="page-title text-capitalize">Get in <span>Touch</span></h2>
                    <p>Morbi consectetur felis nibh, vel condimentum
                        <br> velit vulputate vitae</p>
                </div>
                <div class="space-60"></div>
            </div>
            <div class="row xs-center">
                <div class="col-xs-12 col-sm-3 col-sm-offset-1 wow fadeInUp" data-wow-delay="0.2s">
                    <h3 class="basic-title"><i class="fa fa-phone"></i> Call Us</h3>
                    <p><a href="#">+960 111 234 578</a>
                        <br> <a href="#">+960 111 999</a></p>
                    <div class="space-10"></div>
                </div>
                <div class="col-xs-12 col-sm-3 col-sm-offset-1 wow fadeInUp" data-wow-delay="0.3s">
                    <h3 class="basic-title"><i class="fa fa-map-marker"></i> Address</h3>
                    <p>99 Little street
                        <br> Victoria Park, New York</p>
                    <div class="space-10"></div>
                </div>
                <div class="col-xs-12 col-sm-3 col-sm-offset-1 wow fadeInUp" data-wow-delay="0.4s">
                    <h3 class="basic-title"><i class="fa fa-envelope"></i> Email Us</h3>
                    <p> <a href="#">creative@gmail.com</a>
                        <br> <a href="#">info@creative.net</a>
                    </p>
                    <div class="space-10"></div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-md-7 wow fadeInUp" data-wow-delay="0.2s">
                    <form action="process.php" id="contact-form" method="post">
                        <div class="space-60"></div>
                        <input type="text" class="form-control" id="form-name" name="form-name" placeholder="Your Name" required>
                        <div class="space-30"></div>
                        <input type="email" class="form-control" id="form-email" name="form-email" placeholder="Email Address" required>
                        <div class="space-30"></div>
                        <input type="text" class="form-control" id="form-subject" name="form-subject" placeholder="Subject" required>
                        <div class="space-30"></div>
                        <textarea class="form-control" rows="6" id="form-message" name="form-message" placeholder="Message hare..." required></textarea>
                        <div class="space-30"></div>
                        <button type="submit" class="btn btn-warning active">Send Message</button>
                        <div class="space-60"></div>
                    </form>
                </div>
                <div class="col-xs-12 col-md-5 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="space-60"></div>
                    <div id="maps"></div>
                </div>
            </div>
        </div>
        <div class="space-100"></div>
        <div class="dark-bg">
            <div class="container">
                <div class="row">
                    <div class="space-30"></div>
                    <div class="col-xs-12 col-sm-6 xs-center">
                        <p>&copy; copyright 2017, All Rights Reserved</p>
                    </div>
                    <div class="col-xs-12 col-sm-6 text-right xs-center">
                        <ul class="list-unstyled list-inline team-soical">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                        </ul>
                    </div>
                    <div class="space-10"></div>
                </div>
            </div>
        </div>
    </footer>
    <!--Footer-area-->
    <!--Vendor JS-->
    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <!--Plugin JS-->
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/magnific-popup.min.js"></script>
    <script src="js/contact-form.js"></script>
    <script src="js/masonry.pkgd.min.js"></script>
    <script src="js/responslid.js"></script>
    <script src="js/imagesloaded.js"></script>
    <script src="js/ajaxchimp.js"></script>
    <script src="js/typed.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/counterup.min.js"></script>
    <script src="js/scrollUp.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/plugins.js"></script>
    <!--Active JS-->
    <script src="js/main.js"></script>
    <!--Maps JS-->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBTS_KEDfHXYBslFTI_qPJIybDP3eceE-A&sensor=false"></script>
    <script src="js/maps.js"></script>
</body>

</html>