@section('about')
<section id="about">
        <div class="space-100"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-md-8 col-md-offset-2 text-center wow fadeInUp">
                    <h2 class="page-title text-capitalize">About Our <span>Store</span></h2>
                    <div class="space-20"></div>

                    <p class="text-justify">
                        <b> Sap</b>:<br/>
                        We provide high quality services and solutions in specific SAP domains like ERP, CRM, Hybris C4C, UI5/FIORI, Hybris Marketing, Hybris E-Commerce, HANA etc.
                    </p>
                  
                    <p class="text-justify">
                    <b> Web Development</b>:<br/>
                        We build Static, Dynamic, E-Commerce websites which are secured, with quality for individual, Small, Medium, and Large Scale Industries.
                    </p>
                    <p class="text-justify">
                         <b> Mobile Apps</b>:<br/>
                         We develop user friendly, compatible, highly proficient apps for Android & iOS platform. 
                    </p>
                    <div id="more_about" class="collapse">
                          <p class="text-justify">
                         <b> Consulting</b>:<br/>
                         We do consulting in domain of SAP, Web technologies, Android, iOS both offshore as well as on client location in any part of the globe. 
                    </p>
                      <p class="text-justify">
                         <b> SEO & Digital Marketing</b>:<br/>
                         Digital marketing provide extra edge to online business and we proudly say we are expert in doing SEO as well as Digital marketing.  
                         
                    </p>
                    </div>
                    <div class="space-15"></div>
                    <a href="#more_about" class="btn btn-warning" data-toggle="collapse">Read more</a>
                </div>
            </div>
        </div>
        <div class="space-100"></div>
    </section>
@endsection