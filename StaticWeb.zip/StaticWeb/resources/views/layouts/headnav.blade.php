@section('headnav')
<nav class="navbar navbar-inverse mainmenu-area navbar-fixed-top smoth bg-dark" data-spy="affix" data-offset-top="3">
            <div class="container relative">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainmenu">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a href="#home" class="navbar-brand logo" ><img src="images/logo.png"  style=" height: 70px; width: 76px"alt=""></a>
                </div>
                <div id="mainmenu" class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li><a href="#home">Home</a></li>
                        <li><a href="#about">About</a></li>
                        <li><a href="#contact">Contact</a></li>
                        <li><a href="{{url('/faq')}}">FAQ</a></li>
                       
                        <li><a href="{{url('/policy')}}">Policy</a></li>
                       
                       
                        

                       
                        <li><a href="https://www.instagram.com"> <i class="fa fa-instagram"></i></a> </li>
                        <li> <a href="https://www.whatsapp.com/"><i class="fa fa-whatsapp"></i></a></li>
                        <li><a href="https://twitter.com"><i class="fa fa-twitter"></i></a></li>
                    </ul>
                </div>
            </div>
        </nav>

@endsection