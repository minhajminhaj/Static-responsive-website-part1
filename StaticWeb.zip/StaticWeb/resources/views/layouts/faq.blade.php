@extends('layouts.html')

<nav class="navbar navbar-inverse mainmenu-area navbar-fixed-top smoth bg-dark" data-spy="affix" data-offset-top="3">
            <div class="container relative">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainmenu">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a href="#home" class="navbar-brand logo" ><img src="images/logo.png"  style=" height: 70px; width: 76px"alt=""></a>
                </div>
                <div id="mainmenu" class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li><a href="{{url('/index')}}">Home</a></li>
                        <li><a href="{{url('/index')}}">About</a></li>
                        <li><a href="{{url('/index')}}">Contact</a></li>
                        <li><a href="{{url('/faq')}}">FAQ</a></li>
                       
                        <li><a href="{{url('/policy')}}">Policy</a></li>
                       
                       
                        

                       
                        <li><a href="https://www.instagram.com"> <i class="fa fa-instagram"></i></a> </li>
                        <li> <a href="https://www.whatsapp.com/"><i class="fa fa-whatsapp"></i></a></li>
                        <li><a href="https://twitter.com"><i class="fa fa-twitter"></i></a></li>
                    </ul>
                </div>
            </div>
        </nav>

<section id="faq">
        <div class="space-100"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-md-8">
                    <h2 class="page-title text-capitalize">Frequently ask  <span>Question</span></h2>
                    <div class="space-20"></div>
                    <p>
                    	<button class="btn btn-primary btn-block " type="button" data-toggle="collapse" data-target="#data" aria-expanded="false" aria-controls="data">What does Bootstrap package includes?</button>

                    	<div class="collapse" id="data">
					      <div class="card card-body">
					      	<p class="text-justify">
					       <b> Bootstrap package includes − </b>
					        	<br/><br/> <b>
							Scaffolding</b> − Bootstrap provides a basic structure with Grid System, link styles,background. This is is covered in detail in the section Bootstrap Basic Structure
								<br/><br/><b>
							CSS</b> − Bootstrap comes with feature of global CSS settings, fundamental HTML elements styled and enhanced with extensible classes, and an advanced grid system. This is covered in detail in the section Bootstrap with CSS.
								<br/><br/><b>
							Components </b>− Bootstrap contains over a dozen reusable components built to provide iconography, dropdowns, navigation, alerts, popovers, and much more. This is covered in detail in the section Layout Components.
								<br/><br/><b>
							JavaScript Plugins </b>− Bootstrap contains over a dozen custom jQuery plugins. You can easily include them all, or one by one. This is covered in details in the section Bootstrap Plugins.
								<br/><br/><b>
							Customize </b>− You can customize Bootstrap's components, LESS variables, and jQuery plugins to get your very own version.
						</p>
					      </div>
   						</div>

                    </p>
                    <p>
                    	<button class="btn btn-primary btn-block" type="button" data-toggle="collapse" data-target="#data1" aria-expanded="false" aria-controls="data">Why use Bootstrap?</button>

                    	<div class="collapse" id="data1">
					      <div class="card card-body">
					       <p class="text-justify"><br> <b>
					       	Mobile first approach </b>− Since Bootstrap 3, the framework consists of Mobile first styles throughout the entire library instead of in separate files.
					       		<br><br><b>
							Browser Support</b> − It is supported by all popular browsers.
								<br><br>
							<b>
							Easy to get started</b> − With just the knowledge of HTML and CSS anyone can get started with Bootstrap. Also the Bootstrap official site has a good documentation.
								<br><br><b>
							Responsive design</b> − Bootstrap's responsive CSS adjusts to Desktops,Tablets and Mobiles.
								<br><br>
							Provides a clean and uniform solution for building an interface for developers.
								<br><br>
							It contains beautiful and functional built-in components which are easy to customize.
								<br><br>
							It also provides web based customization.
								<br><br>
							And best of all it is an open source.


					       </p>
					      </div>
   						</div>

                    </p>
                    <p>
                    	<button class="btn btn-primary btn-block" type="button" data-toggle="collapse" data-target="#data3" aria-expanded="false" aria-controls="data">How can you order columns in Bootstrap?</button>

                    	<div class="collapse" id="data3">
					      <div class="card card-body">
					        <p class="text-justify">
					        	<br>
					        	You can easily change the order of built-in grid columns with .col-md-push-* and .col-md-pull-* modifier classes where * range from 1 to 11.
					        	

					        </p>
					      </div>
   						</div>

                    </p>
                    <p>
                    	<button class="btn btn-primary btn-block" type="button" data-toggle="collapse" data-target="#data4" aria-expanded="false" aria-controls="data">Explain the typography and links in Bootstrap !</button>

                    	<div class="collapse" id="data4">
					      <div class="card card-body">
					       <p class="text-justify"><br><b>
					       	Basic Global display</b> − Sets background-color: #fff; on the &lt; body &gt;element.
					       		<br><br><b>
							Typography</b> − Uses the @font-family-base, @font-size-base, and @line-height-base attributes as the typographic base
								<br><br>	<b>
							Link styles </b> − Sets the global link color via attribute @link-color and apply link underlines only on :hover.
					       	
					       </p>
					      </div>
   						</div>

                    </p>
                    
                    
                </div>
            </div>
        </div>
        <div class="space-100"></div>
    </section>



@section('footer')
@include('layouts.footer')
@endsection

