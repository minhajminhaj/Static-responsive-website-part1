@extends('layouts.html')
<nav class="navbar navbar-inverse mainmenu-area navbar-fixed-top smoth bg-dark" data-spy="affix" data-offset-top="3">
            <div class="container relative">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainmenu">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a href="#home" class="navbar-brand logo" ><img src="images/logo.png"  style=" height: 70px; width: 76px"alt=""></a>
                </div>
                <div id="mainmenu" class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                        <li><a href="{{url('/index')}}">Home</a></li>
                        <li><a href="{{url('/index')}}">About</a></li>
                        <li><a href="{{url('/index')}}">Contact</a></li>
                        <li><a href="{{url('/faq')}}">FAQ</a></li>
                       
                        <li><a href="{{url('/policy')}}">Policy</a></li>
                       
                       
                        

                       
                        <li><a href="https://www.instagram.com"> <i class="fa fa-instagram"></i></a> </li>
                        <li> <a href="https://www.whatsapp.com/"><i class="fa fa-whatsapp"></i></a></li>
                        <li><a href="https://twitter.com"><i class="fa fa-twitter"></i></a></li>
                    </ul>
                </div>
            </div>
        </nav>
<section id="policy">
        <div class="space-100"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-md-8 col-md-offset-2 text-center wow fadeInUp">
                    <h2 class="page-title text-capitalize">Know about our <span>policy</span></h2>
                    <div class="space-20"></div>
                    <p class="text-justify">
                        Apps are changing the world, enriching people’s lives, and enabling developers like you to innovate like never before. As a result, the App Store has grown into an exciting and vibrant ecosystem for millions of developers and more than a billion users. Whether you are a first time developer or a large team of experienced programmers, we are excited that you are creating apps for the App Store and want to help you understand our guidelines so you can be confident your app will get through the review process quickly.
<br>
The guiding principle of the App Store is simple - we want to provide a safe experience for users to get apps and a great opportunity for all developers to be successful. On the following pages you will find guidelines arranged into five clear sections: Safety, Performance, Business, Design, and Legal. <br>
<b> A few other points to keep in mind: </b><br>
</p>
                    <div id="more_about" class="collapse">
                       
                        <p class="text-justify">
                            We have lots of kids downloading lots of apps. Parental controls work great to protect kids, but you have to do your part too. So know that we’re keeping an eye out for the kids.
The App Store is a great way to reach hundreds of millions of people around the world. If you build an app that you just want to show to family and friends, the App Store isn’t the best way to do that. Consider using Xcode to install your app on a device for free or use Ad Hoc distribution available to Apple Developer Program members. If you’re just getting started, learn more about the Apple Developer Program.
We strongly support all points of view being represented on the App Store, as long as the apps are respectful to users with differing opinions and the quality of the app experience is great. We will reject apps for any content or behavior that we believe is over the line. What line, you ask? Well, as a Supreme Court Justice once said, “I’ll know it when I see it”. And we think that you will also know it when you cross it.
If you attempt to cheat the system (for example, by trying to trick the review process, steal user data, copy another developer’s work, or manipulate ratings) your apps will be removed from the store and you will be expelled from the Developer Program.
You are responsible for making sure everything in your app complies with these guidelines, including ad networks, analytics services, and third-party SDKs, so review and choose them carefully.
We hope these guidelines help you sail through the App Review process, and that approvals and rejections remain consistent across the board. This is a living document; new apps presenting new questions may result in new rules at any time. Perhaps your app will trigger this. We love this stuff too, and honor what you do. We’re really trying our best to create the best platform in the world for you to express your talents and make a living, too.
                            
                        </p>
                    </div>
                    <div class="space-15"></div>
                    <a href="#more_about" class="btn btn-warning" data-toggle="collapse">Read more</a>
                </div>
            </div>
        </div>
        <div class="space-100"></div>
    </section>
@section('footer')
@include('layouts.footer')
@endsection
