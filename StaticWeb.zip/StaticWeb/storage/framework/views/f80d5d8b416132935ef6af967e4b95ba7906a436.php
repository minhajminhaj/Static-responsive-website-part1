<?php $__env->startSection('service'); ?>
<section class="dark-bg" id="service">
        <div class="space-100"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-sm-offset-3 text-center">
                    <h2 class="page-title text-capitalize">our <span>Service</span></h2>
                    <p>Morbi consectetur felis nibh, vel condimentum
                        <br> velit vulputate vitae</p>
                </div>
            </div>
            <div class="space-60"></div>
            <div class="row wow fadeInUp">
                <div class="col-xs-12 col-sm-5 col-md-3">
                    <div class="space-20"></div>
                    <ul class="list-unstyled service-menu">
                        <li class="active"><a data-toggle="tab" href="#service_1">01. Branding Design</a></li>
                        <li><a data-toggle="tab" href="#service_2">02. Marketing Solutions</a></li>
                        <li><a data-toggle="tab" href="#service_3">0.3 Photography</a></li>
                        <li><a data-toggle="tab" href="#service_4">0.4 Digital Illustration</a></li>
                        <li><a data-toggle="tab" href="#service_5">0.5 UI Design</a></li>
                    </ul>
                </div>
                <div class="col-xs-12 col-sm-7 col-md-9">
                    <div class="tab-content">
                        <div class="tab-pane fade in active" id="service_1">
                            <div class="row">
                                <div class="col-xs-12 col-md-5">
                                    <div class="service-photo">
                                        <img src="images/software.jpg"  alt="" class="img-thumbnail">
                                    </div>
                                </div>
                                <div class="col-xs-12 col-md-7">
                                    <div class="space-20"></div>
                                    <h2>Branding Design</h2>
                                    <div class="space-10"></div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. o eiusmod tempor incididunt ut labore et dolore magna aliqua. dolore magna aliqua. Ut enim ad minim veniam, Qfis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="service_2">
                            <div class="row">
                                <div class="col-xs-12 col-md-5">
                                    <div class="service-photo">
                                        <img src="images/service/sol2.jpg" alt="" class="img-thumbnail">
                                    </div>
                                </div>
                                <div class="col-xs-12 col-md-7">
                                    <div class="space-20"></div>
                                    <h2>Marketing Solutions</h2>
                                    <div class="space-10"></div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. o eiusmod tempor incididunt ut labore et dolore magna aliqua. dolore magna aliqua. Ut enim ad minim veniam, Qfis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="service_3">
                            <div class="row">
                                <div class="col-xs-12 col-md-5">
                                    <div class="service-photo">
                                        <img src="images/service/sol3.jpg" alt="" class="img-thumbnail">
                                    </div>
                                </div>
                                <div class="col-xs-12 col-md-7">
                                    <div class="space-20"></div>
                                    <h2>Photography</h2>
                                    <div class="space-10"></div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. o eiusmod tempor incididunt ut labore et dolore magna aliqua. dolore magna aliqua. Ut enim ad minim veniam, Qfis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="service_4">
                            <div class="row">
                                <div class="col-xs-12 col-md-5">
                                    <div class="service-photo">
                                        <img src="images/service/sol4.jpg" alt="" class="img-thumbnail">
                                    </div>
                                </div>
                                <div class="col-xs-12 col-md-7">
                                    <div class="space-20"></div>
                                    <h2>Digital Illustration</h2>
                                    <div class="space-10"></div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. o eiusmod tempor incididunt ut labore et dolore magna aliqua. dolore magna aliqua. Ut enim ad minim veniam, Qfis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="service_5">
                            <div class="row">
                                <div class="col-xs-12 col-md-5">
                                    <div class="service-photo">
                                        <img src="images/service/sol5.jpg" alt="" class="img-thumbnail">
                                    </div>
                                </div>
                                <div class="col-xs-12 col-md-7">
                                    <div class="space-20"></div>
                                    <h2>Digital Illustration</h2>
                                    <div class="space-10"></div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. o eiusmod tempor incididunt ut labore et dolore magna aliqua. dolore magna aliqua. Ut enim ad minim veniam, Qfis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="space-100"></div>
    </section>
<?php $__env->stopSection(); ?>