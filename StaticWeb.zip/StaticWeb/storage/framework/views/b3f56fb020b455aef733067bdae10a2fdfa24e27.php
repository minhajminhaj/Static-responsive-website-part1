

<?php $__env->startSection('appstore'); ?>
<section class="dark-bg" id="appstore">
        <div class="space-100"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-sm-offset-3 text-center">
                    <h2 class="page-title text-capitalize">app  <span>store</span></h2>
                    <p>you will get our app services form here
                         </p>
                </div>
                <div class="space-10"></div>
            </div>
            <div class="text-center">
                <div class="" data-wow-delay="0.2s">
                    <div class="single-team relative efbarm">
                    <p class="text-justify">
                         <b> Consulting</b>:<br/>
                         We do consulting in domain of SAP, Web technologies, Android, iOS both offshore as well as on client location in any part of the globe. 
                    </p>
                      <p class="text-justify">
                         <b> SEO & Digital Marketing</b>:<br/>
                         Digital marketing provide extra edge to online business and we proudly say we are expert in doing SEO as well as Digital marketing.  
                    </p>
           

               <p class="text-justify">
                    <b> Web Development</b>:<br/>
                                    We build Static, Dynamic, E-Commerce websites which are secured, with quality for individual, Small, Medium, and Large Scale Industries.
                      </p>
                       <p class="text-justify">
                                   <b> Mobile Apps</b>:<br/>
                                     We develop user friendly, compatible, highly proficient apps for Android & iOS platform.
                        </p>
    

                    </div>
                    <div class="space-40"></div>
                    <a href="http://primeitzen.com/services/mobile-application" class="btn btn-warning" >Read More</a>
                </div>
            </div>
                </div>
              
            
        
        <div class="space-100"></div>
    </section>

<?php $__env->stopSection(); ?>