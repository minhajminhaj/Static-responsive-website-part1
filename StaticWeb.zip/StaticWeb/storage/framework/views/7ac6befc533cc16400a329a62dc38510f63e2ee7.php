<?php $__env->startSection('team'); ?>
<section class="dark-bg" id="team">
        <div class="space-100"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-sm-offset-3 text-center">
                    <h2 class="page-title text-capitalize">See some  <span>vedios</span></h2>
                    <p>Two vedios are attached for Responsive website
                        <br> middle one is for funny </p>
                </div>
                <div class="space-60"></div>
            </div>
            <div class="row text-center">
                <div class="col-xs-12 col-sm-4 wow fadeInUp" data-wow-delay="0.2s">
                    <div class="single-team relative efbarm">
                        <div class="efbar">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>


                        <div class="embed-responsive embed-responsive-16by9">
  <iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/9cKsq14Kfsw?start=4" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div><span></span>
<div> <h3> Responvise vedio 1</h3></div>
                        <div class="vcenter">
                            <div class="team-details">
                                <h3 class="team-title">PrimeITzen</h3>
                                <p>Minhaj</p>
                                <ul class="list-unstyled list-inline team-soical">
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="single-team relative efbarm">
                        <div class="efbar">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div class="embed-responsive embed-responsive-16by9">
                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/zpOULjyy-n8?rel=0" allowfullscreen></iframe>
                        </div>
                        <div> <h3> Funny vedio</h3></div>
                        <div class="vcenter">
                            <div class="team-details">
                                <h3 class="team-title">PrimeITzen</h3>
                                <p>Minhaj</p>
                                <ul class="list-unstyled list-inline team-soical">
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4 wow fadeInUp" data-wow-delay="0.4s">
                    <div class="single-team relative efbarm">
                        <div class="efbar">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div class="embed-responsive embed-responsive-16by9">
                        <iframe width="560" height="315" src="https://www.youtube.com/embed/9YffrCViTVk" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>
                        <div> <h3> Responvise vedio 2</h3></div>
                        <div class="vcenter">
                            <div class="team-details">
                                <h3 class="team-title">PrimeITzen</h3>
                                <p>Minhaj</p>
                                <ul class="list-unstyled list-inline team-soical">
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="space-100"></div>
    </section>

<?php $__env->stopSection(); ?>