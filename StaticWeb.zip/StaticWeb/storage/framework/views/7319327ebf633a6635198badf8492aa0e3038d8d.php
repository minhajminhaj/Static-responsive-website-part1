<?php $__env->startSection('header'); ?>
<header class="relative" id="home">
        <div class="absolute section-overlay home-slide fix">
            <img src="images/bg/bgg3.jpg" alt="">
            <img src="images/bg/bgg2.jpg" alt="">
            
            
        </div>
        

<div class="container">
            <div class="row text-white">
                <div class="space-100"></div>
                <div class="space-100"></div>
                <div class="space-100 hidden-xs"></div>
                <div class="col-xs-12 text-center wow fadeIn" data-wow-delay="0.6s">
                    <h2 class="head-title">We Have Amazing <span class="type">web Developper </span></h2>
                    <div class="space-10"></div>
                    <p>PrimeItzen providing software soluation, consultancy and services.
                        </p>
                    <div class="space-30"></div>
                    <a href="#" class="btn btn-warning round">View more</a>
                </div>
                <div class="space-100"></div>
                <div class="space-100"></div>
            </div>
        </div>
    </header>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.html', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>