<?php $__env->startSection('footer'); ?>
<footer id="contact">
        <div class="space-100"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-sm-offset-3 text-center">
                    <h2 class="page-title text-capitalize">Get in <span>Touch</span></h2>
                    <p>Morbi consectetur felis nibh, vel condimentum
                        <br> velit vulputate vitae</p>
                </div>
                <div class="space-60"></div>
            </div>
            <div class="row xs-center">
                <div class="col-xs-12 col-sm-3 col-sm-offset-1 wow fadeInUp" data-wow-delay="0.2s">
                    <h3 class="basic-title"><i class="fa fa-phone"></i> Call Us</h3>
                    <p><a href="#">+960 111 234 578</a>
                        <br> <a href="#">+960 111 999</a></p>
                    <div class="space-10"></div>
                </div>
                <div class="col-xs-12 col-sm-3 col-sm-offset-1 wow fadeInUp" data-wow-delay="0.3s">
                    <h3 class="basic-title"><i class="fa fa-map-marker"></i> Address</h3>
                    <p>99 Little street
                        <br> Victoria Park, New York</p>
                    <div class="space-10"></div>
                </div>
                <div class="col-xs-12 col-sm-3 col-sm-offset-1 wow fadeInUp" data-wow-delay="0.4s">
                    <h3 class="basic-title"><i class="fa fa-envelope"></i> Email Us</h3>
                    <p> <a href="#">creative@gmail.com</a>
                        <br> <a href="#">info@creative.net</a>
                    </p>
                    <div class="space-10"></div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-md-7 wow fadeInUp" data-wow-delay="0.2s">
                    <form action="process.php" id="contact-form" method="post">
                        <div class="space-60"></div>
                        <input type="text" class="form-control" id="form-name" name="form-name" placeholder="Your Name" required>
                        <div class="space-30"></div>
                        <input type="email" class="form-control" id="form-email" name="form-email" placeholder="Email Address" required>
                        <div class="space-30"></div>
                        <input type="text" class="form-control" id="form-subject" name="form-subject" placeholder="Subject" required>
                        <div class="space-30"></div>
                        <textarea class="form-control" rows="6" id="form-message" name="form-message" placeholder="Message hare..." required></textarea>
                        <div class="space-30"></div>
                        <button type="submit" class="btn btn-warning active">Send Message</button>
                        <div class="space-60"></div>
                    </form>
                </div>
                <div class="col-xs-12 col-md-5 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="space-60"></div>
                    <div id="maps"></div>
                </div>
            </div>
        </div>
        <div class="space-100"></div>
        <div class="dark-bg">
            <div class="container">
                <div class="row">
                    <div class="space-30"></div>
                    <div class="col-xs-12 col-sm-6 xs-center">
                        <p>&copy; copyright 2017, All Rights Reserved</p>
                    </div>
                    <div class="col-xs-12 col-sm-6 text-right xs-center">
                        <ul class="list-unstyled list-inline team-soical">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                        </ul>
                    </div>
                    <div class="space-10"></div>
                </div>
            </div>
        </div>
    </footer>
<?php $__env->stopSection(); ?>